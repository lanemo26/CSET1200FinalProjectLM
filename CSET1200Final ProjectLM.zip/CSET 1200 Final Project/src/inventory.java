//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> ic
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class inventory {
    private static List<Product> inventory = new ArrayList<>();
    private static List<Sale> sales = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("Inventory Management");
            System.out.println("Please Select Option (Numeric Values Only)");
            System.out.println("1. Show Inventory");
            System.out.println("2. Add Inventory");
            System.out.println("3. Delete Inventory");
            System.out.println("4. Purchase Product");
            System.out.println("5. Show Sales");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    showInventory();
                    break;
                case 2:
                    addInventory();
                    break;
                case 3:
                    deleteInventory();
                    break;
                case 4:
                    purchaseProduct();
                    break;
                case 5:
                    showSales();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid Selection, Please try again.");
            }
        }
    }

    private static void showInventory() {
        System.out.println("Inventory:");
        for (int i = 0; i < inventory.size(); i++) {
            Product product = inventory.get(i);
            System.out.println(i + ". " + product);
        }
    }

    private static void addInventory() {
        System.out.print("Enter product name: ");
        String productName = scanner.nextLine();
        System.out.print("Enter price (numeric values only): ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Enter seller: ");
        String seller = scanner.nextLine();
        Date currentDate = new Date();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < quantity; i++) {
            Product product = new Product(productName, price, seller, currentDate);
            inventory.add(product);
        }

        System.out.println(quantity + " product has been added successfully");
    }

    private static void deleteInventory() {
        showInventory();
        System.out.print("Enter index of product to delete: ");
        int index = scanner.nextInt();
        if (index >= 0 && index < inventory.size()) {
            inventory.remove(index);
            System.out.println("Product deleted from inventory.");
            showInventory();
        } else {
            System.out.println("Invalid Selection");
        }
    }

    private static void purchaseProduct() {
        showInventory();
        System.out.print("Enter index of product to purchase: ");
        int index = scanner.nextInt();
        scanner.nextLine();
        if (index >= 0 && index < inventory.size()) {
            Product product = inventory.get(index);
            System.out.print("Enter purchaser's name: ");
            String purchaser = scanner.nextLine();

            inventory.remove(index);
            sales.add(new Sale(product, purchaser, new Date()));
            System.out.println("Product purchased successfully.");
        } else {
            System.out.println("Invalid index.");
        }
    }

    private static void showSales() {
        System.out.println("Sales:");
        for (Sale sale : sales) {
            System.out.println(sale);
        }
    }

    static class Product {
        private String productName;
        private double price;
        private String seller;
        private Date dateAdded;

        public Product(String description, double price, String seller, Date dateAdded) {
            this.productName = description;
            this.price = price;
            this.seller = seller;
            this.dateAdded = dateAdded;
        }
        public String toString() {
            return productName + " | Price: " + price + " | Seller: " + seller + " | Date Added: " + dateAdded;
        }
    }

    static class Sale {
        private Product product;
        private String purchaser;
        private Date date;

        public Sale(Product product, String purchaser, Date date) {
            this.product = product;
            this.purchaser = purchaser;
            this.date = date;
        }
        public String toString() {
            return product.productName + " | Purchaser: " + purchaser + " | Date: " + date;
        }
    }
}
